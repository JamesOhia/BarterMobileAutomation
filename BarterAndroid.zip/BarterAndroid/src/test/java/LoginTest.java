import actions.CapabilitySetup;
public class LoginTest extends CapabilitySetup{
    @io.cucumber.java.en.Given("Click on login button")
    public void clickOnLoginButton() {
    }

    @io.cucumber.java.en.Given("Click email tab")
    public void clickEmailTab() {
    }

    @io.cucumber.java.en.Given("Enter email address")
    public void enterEmailAddress() {
    }

    @io.cucumber.java.en.Given("Click continue button")
    public void clickContinueButton() {
    }

    @io.cucumber.java.en.Given("Enter password")
    public void enterPassword() {
    }

    @io.cucumber.java.en.Given("Click on the show password icon")
    public void clickOnTheShowPasswordIcon() {
    }

    @io.cucumber.java.en.Given("Click on the login button")
    public void clickOnTheLoginButton() {
    }

    @io.cucumber.java.en.When("Click on not now button")
    public void clickOnNotNowButton() {
    }

    @io.cucumber.java.en.Then("User should be on the dashboard")
    public void userShouldBeOnTheDashboard() {
    }
}
